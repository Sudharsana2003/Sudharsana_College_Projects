const express = require('express');
const mongodb = require('mongodb').MongoClient;
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

// Use body-parser middleware to parse JSON and URL-encoded request bodies
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use(express.static(__dirname));

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/patientInfo.html');
});

app.post('/example', async (req, res) => {
  // Ensure that the request body is parsed before attempting to destructure
  if (!req.body) {
    return res.status(400).send('Bad Request: Missing request body');
  }

  const { firstName, lastName, age, gender, email } = req.body;
  try {
    const client = await mongodb.connect('mongodb://127.0.0.1:27017');
    const db = client.db('PATIENT_RECORDS_KCET');
    const collection = db.collection('patients');

    await collection.insertOne({ 
      firstName,
      lastName,
      age: parseInt(age),
      gender,
      email
    });
    res.send('Patient information stored successfully!');
  } catch (error) {
    console.error('Error:', error);
    res.status(500).send('Internal Server Error');
  }
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
