// Declare a global variable to store the average value
let averageValue = 0;

document.addEventListener('DOMContentLoaded', () => {
    try {
        let dataCount = 0;
        let dataSum = 0;
        const first5Values = [];

        async function requestSerialPortPermission() {
            try {
                const port = await navigator.serial.requestPort();
                await port.open({ baudRate: 9600 });
                const reader = port.readable.getReader();

                while (dataCount < 50) {
                    const { value, done } = await reader.read();
                    if (done || dataCount >= 50) break;

                    const text = new TextDecoder().decode(value);
                    const floatValue = parseFloat(text);

                    if (!isNaN(floatValue)) {
                        dataSum += floatValue;
                        dataCount++;
                        first5Values.push(floatValue);
                    } else {
                        console.error('Invalid data received:', text);
                    }
                }

                averageValue = dataCount > 0 ? dataSum / dataCount : 0;
                updatePage(averageValue, first5Values);
            } catch (error) {
                console.error('Error opening serial port:', error);
            }
        }

        function updatePage(average, values) {
            const emgValueDisplay = document.getElementById('emgValueDisplay');
            if (emgValueDisplay) {
                emgValueDisplay.innerHTML = `
                    <p>Average of first 50 data points: ${average.toFixed(2)}</p>
                    <div class="first-5-values-box">
                        <p>First 50 values:</p>
                        <ul>
                            ${values.map(value => `<li>${value.toFixed(2)}</li>`).join('')}
                        </ul>
                    </div>
                `;
            } else {
                console.error('Error: Element with ID "emgValueDisplay" not found');
            }
        }

        const requestPermissionButton = document.getElementById('requestPermissionButton');
        if (requestPermissionButton) {
            requestPermissionButton.addEventListener('click', requestSerialPortPermission);
        } else {
            console.error('Error: requestPermissionButton element not found');
        }
    } catch (error) {
        console.error('Error:', error);
    }
});


